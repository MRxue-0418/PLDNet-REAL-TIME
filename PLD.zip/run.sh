python val.py --data data/coco.yaml --img 640 --batch 32 --conf 0.001 --iou 0.7 --device cpu  --weights './yolov9-c-converted.pt' --save-json --name yolov9_c_c_640_val
python train_dual.py --weights './yolov9-c.pt' --cfg models/detect/yolov9-c.yaml --data yolo/data.yaml --epochs 5 --batch-size 2 --device cpu
# cpu
python train_dual.py --weights './yolov9-c.pt' --cfg models/detect/yolov9-c.yaml --data yolo/data.yaml --epochs 5 --batch-size 2 --device cuda:0 --workers 8
# GPU
python train_dual.py --weights './yolov9-c.pt' --cfg models/detect/yolov9-c.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8

python detect_dual.py --weights D:\AI\yolov9-main\runs\train\sickfishandnormal_trainfocal\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\sickfishsite124.jpg --device cuda:0
# 预测

python train_dual.py --weights './yolov9-c.pt' --cfg models/detect/SPD-Conv_yolov9-c.yaml --data ./data.yaml --epochs 5 --batch-size 2 --device cuda:0 --workers 8

python train_dual.py --weights './yolov9-c.pt' --cfg models/detect/yolov9-c_SENetV2_SPD.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8 

python train_dual.py --weights 'D:\AI\yolov9-main\runs\train\sickfishandnormal_train4\weights\last.pt' --cfg models/detect/yolov9-c_SENetV2_SPD.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8 --resume True

python train_dual.py --weights './yolov9-c.pt' --cfg SENetV1_YOLOV9C.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8 

python train_dual.py --weights 'D:\AI\yolov9-main\runs\fish\sickfishandnormal_train4SPD-head\weights\best.pt' --cfg yolov9-c.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8  

python train_dual.py --weights 'D:\AI\yolov9-main\runs\fish\sickfishandnormal_train4SPD-head\weights\best.pt' --cfg models/detect/yolov9-c_FocalModulation.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8 

python detect_dual.py --weights D:\AI\yolov9-main\runs\train\sickfishandnormal_trainfocal\weights\last.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\sickfishsite107.jpg --device cuda:0

python detect_dual.py --weights D:\AI\yolov9-main\runs\fish\sickfishandnormal_train4yolov9m\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\sickfishsite124.jpg --device cuda:0

python train_dual.py --weights './yolov9-m.pt' --cfg models/detect/yolov9-m.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8.

python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8 

python detect_dual.py --weights D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\sickfishsite124.jpg --device cuda:0


python detect_dual.py --weights D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\chenguang\train\images\iCGVedio_sickfish_1_283.jpg --device cuda:0
12.8
python train_dual.py --weights '"D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt"' --cfg models/detect/yolov9-c_FocalModulation.yaml --data ./dataAugCG.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8 

D:\AI\yolov9-main\runs\train\sickfishandnormal_train7CG\weights
python detect_dual.py --weights D:\AI\yolov9-main\runs\train\sickfishandnormal_train7CG\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\sickfishsite124.jpg --device cuda:0
python detect_dual.py --weights D:\AI\yolov9-main\runs\train\sickfishandnormal_train7CG\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\CGVedio_sickfish_3_127.jpg --device cuda:0
12.9
python train_dual.py --weights '"D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt"' --cfg models/detect/yolov9-c_FocalModulation.yaml --data ./data.yaml --epochs 400 --batch-size 2 --device cuda:0 --workers 8 

12.10
python detect_dual.py --weights D:\AI\yolov9-main\runs\train\sickfishandnormal_train7\weights\best.pt  --img-size 640 --source D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\images\VID_20230414_154212-0185.jpg --device cuda:0

python detect_dual.py --weights D:\AI\yolov9-main\runs\train\sickfishandnormal_train7\weights\best.pt --img-size 640 --source D:\AI\ultralytics\ChenGuang_Vedio\CGVedio_sickfish_2.mp4 --device cuda:0

python val_dual.py --weights 'D:\AI\yolov9-main\runs\train\sickfishandnormal_train7\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8
#sickandnormal3 data_a水上测试集验证 把3换成2 valid_a与valid 交换名字
python val_dual.py --weights 'D:\AI\yolov9-main\runs\train\sickfishandnormal_train7\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8
#sickandnormal3 data_b水下测试集验证 把3换成2 valid_b与valid 交换名字
验证的时候直接改dataset名字 val自己变   python val_dual.py --weights 'D:\AI\yolov9-main\runs\train\sickfishandnormal_train7\weights\best.pt'  --data ./data_sickandnormal3.yaml 这个data没用到啊 可能和训练的时候有关系吧--batch-size 2 --device cuda:0 --workers 8 
消融实验
python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\sickfishandnormal_train9focalnoiou\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8
python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8
python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\sickfishandnormal_train4iou\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8
fps
python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\sickfishandnormal_train4yolov9m\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8

python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\sickfishandnormal_train5_400_V9C\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8

python val_dual.py --weights 'D:\\AI\\yolov9-main\\runs\\fish\\train23（5.7）NOSEA400sickandnormal\\weights\\best.pt'  --data D:/AI/YOLO_fishdetection/datasets/sickandnormal/data.yaml  --batch-size 2 --device cuda:0 --workers 8

python val_dual.py --weights 'D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt'  --data ./data.yaml  --batch-size 2 --device cuda:0 --workers 8


124

D:\AI\YOLO_fishdetection\datasets\sickandnormal2\test\OUTPUT2
python detect_dual.py --weights D:\AI\yolov9-main\runs\fish\last——sickfishandnormal_trainfocal\weights\best.pt  --img-size 640 --source D:\\AI\\YOLO_fishdetection\\datasets\\sickandnormal2\\test\\OUTPUT2\\sickfishsite124.jpg --device cuda:0